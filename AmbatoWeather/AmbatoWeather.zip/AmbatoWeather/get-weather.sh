#!/bin/bash

# Define el path al entorno virtual si es necesario
# source /home/belen/AmbatoWeather/AmbatoWeather/env/bin/activate

# Define el path al script de Python
SCRIPT_PATH="/home/belen/AmbatoWeather/AmbatoWeather/main.py"

# Ejecuta el script de Python
python3 "$SCRIPT_PATH"
