#!/usr/bin/sh
emacs -Q --script build-site.el
